﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PFAClientCore
{
    class DLLManager
    {
        private List<PluginManager> pluginsOfClient;
 
        //  Methods

        public DLLManager()
        {
            this.pluginsOfClient = new List<PluginManager>();
        }

        private List<string> getFilePaths(string directoryName)
        {
            string[] filePaths = Directory.GetFiles(directoryName);
            List<string> pluginsFilePaths = filePaths.ToList<string>();

            if (pluginsFilePaths.Count == 0)
                throw (new System.Exception("There are not files in " + directoryName + " directory"));
            int counter = -1;
            while (++counter < pluginsFilePaths.Count)
                if (Path.GetExtension(pluginsFilePaths[counter]) != ".dll" || Path.GetFileName(pluginsFilePaths[counter]).Contains("APlugin") == true
                    || Path.GetFileName(pluginsFilePaths[counter]).Contains("LibNet") == true)
                {
                    pluginsFilePaths.RemoveAt(counter);
                    counter = -1;
                }
            counter = -1;
            while (++counter < pluginsFilePaths.Count)
            {
                pluginsFilePaths[counter] = pluginsFilePaths[counter].Replace("\\\\", "\\");
            }
            return (pluginsFilePaths);
        }

        private void checkOfFile()
        {

        }

        private void loadDLL(List<string> pluginsFilePaths)
        {
            int counter = 0;

            while (counter < pluginsFilePaths.Count)
            {
                Assembly dllToAdd = Assembly.LoadFrom(pluginsFilePaths[counter]);
                PluginManager pluginToAdd = new PluginManager();
                pluginToAdd.setFilePath(pluginsFilePaths[counter]);
                pluginToAdd.setExecutableDLL(dllToAdd);
                pluginToAdd.setClass();
                pluginToAdd.setNumberOfPlugin(counter);
                this.pluginsOfClient.Add(pluginToAdd);
                ++counter;
            }
        }

        public PluginManager getPluginAt(int index)
        {
            Console.WriteLine(index + " :: " + this.pluginsOfClient.Count);
            if (index >= 0 && index < this.pluginsOfClient.Count)
                return (this.pluginsOfClient[index]);
            return (null);
        }

        public void loadPlugins(string directoryName)
        {
            List<String> listOfPluginsPaths = this.getFilePaths(directoryName);
            this.loadDLL(listOfPluginsPaths);
        }

        public List<PluginManager> getPluginsOfClient()
        {
            return (this.pluginsOfClient);
        }

        public void setPluginsOfClient(List<PluginManager> pluginsToSet)
        {
            this.pluginsOfClient = pluginsToSet;
        }

    }
}
