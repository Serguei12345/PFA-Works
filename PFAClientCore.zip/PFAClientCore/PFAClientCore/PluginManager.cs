﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PFAClientCore
{
    class PluginManager
    {
        string filePath;
        Assembly executableDLL;
        int numberOfPlugin;
        APlugin classToUse;

        // Methods

        public PluginManager()
        {
        }

        public void setFilePath(string filePathToSet)
        {
            this.filePath = filePathToSet;
        }
        
        public void setExecutableDLL(Assembly executableDLLToSet)
        {
            this.executableDLL = executableDLLToSet;
        }

        public void setNumberOfPlugin(int numberOfPluginToSet)
        {
            this.numberOfPlugin = numberOfPluginToSet;
        }

        public string getFilePath()
        {
            return (this.filePath);
        }

        public Assembly getExecutableDLL()
        {
            return (executableDLL);
        }

        public int getNumberOfPlugin()
        {
            return (this.numberOfPlugin);
        }

        public APlugin getPluginObject()
        {
            return (this.classToUse);
        }

        public void setPluginObject(APlugin objectToSet)
        {
            this.classToUse = objectToSet;
        }

        public void setClass()
        {
            Module[] modules = this.executableDLL.GetModules();
            if (modules.Length != 1)
                throw (new System.Exception("Il y a plusieurs modules dans la librairie dynamique avec le chemin " + this.filePath));
            if (modules == null || modules[0] == null)
                Console.WriteLine("SWAG");
            modules[0].GetTypes();
            string nameOfMainClass = this.getNameOfMainClass(modules[0].GetTypes());
            if (nameOfMainClass == "")
                throw (new System.Exception("Il n'y a pas de classe avec la methode doRequest à l'intérieur " + this.filePath));
            Type type = this.executableDLL.GetType(nameOfMainClass);
            ConstructorInfo ci = type.GetConstructor(Type.EmptyTypes);
            this.classToUse = (APlugin)ci.Invoke(new object[] { });
        }

        public void useDoRequestFunction(List<byte> datas, mognetwork.TcpSocket tcpSocketToUse)
        {
            Type type = this.classToUse.GetType();
            MethodInfo mi = type.GetMethod("doRequest");
            mi.Invoke(this.classToUse, new object[] { datas, tcpSocketToUse });
        }

        String getNameOfMainClass(Type[] types)
        {
            int counterTypes = 0;
            int counterMethods;

            while (counterTypes < types.Length)
            {
                MethodInfo[] methodInfos = types[counterTypes].GetMethods();
                counterMethods = 0;
                while (counterMethods < methodInfos.Length)
                {
                    if (methodInfos[counterMethods].Name == "doRequest")
                        return (types[counterTypes].FullName);
                    ++counterMethods;
                }
                ++counterTypes;
            }
            return ("");
        }
    }
}
