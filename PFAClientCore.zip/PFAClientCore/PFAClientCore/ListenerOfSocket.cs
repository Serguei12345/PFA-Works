﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFAClientCore
{
    class ListenerOfSocket : mognetwork.ListenerHandler
    {
        DLLManager dllManager;
        mognetwork.TcpSocket socketToUse;

        public ListenerOfSocket()
        {

        }

        public void setDLLManager(DLLManager dllManagerToSet)
        {
            this.dllManager = dllManagerToSet;
        }


        public void setTcpSocket(mognetwork.TcpSocket socketToSet)
        {
            this.socketToUse = socketToSet;
        }

        public void onMessageReceived(List<byte> datas)
        {
            try
            {
                int numberOfPlugin;
                byte[] pluginNumberBytes = { datas[0], datas[1], datas[2], datas[3] };

                if (datas.Count <= 4)
                    throw (new System.Exception("Invalid received datas"));

                numberOfPlugin = BitConverter.ToInt32(pluginNumberBytes, 0);
                Console.WriteLine("Number of plugin : " + numberOfPlugin);
                for (int counter = 0; counter < 4; counter = counter + 1)
                    datas.RemoveAt(0);
                PluginManager pm = this.dllManager.getPluginAt(numberOfPlugin);
                if (pm == null)
                    throw (new System.Exception("Le plugin demandé est invalide"));
                pm.useDoRequestFunction(datas, socketToUse);
            }
            catch (System.Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
