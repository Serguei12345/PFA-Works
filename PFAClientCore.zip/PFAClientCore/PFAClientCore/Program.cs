﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFAClientCore
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DLLManager dllManager = new DLLManager();
                dllManager.loadPlugins(".\\Plugins");
                Console.Write("Entrez votre adresse IP : ");
                String ipAdress = Console.ReadLine();
                Console.Write("Entrez votre port : ");
                String port = Console.ReadLine();
                ClientCNM ccnm = new ClientCNM(ipAdress, port);
                ccnm.startClient(dllManager);
            }
            catch (System.Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.Read();
        }
    }
}
