﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace PFAClientCore
{
    class ClientCNM
    {
        mognetwork.TcpSocket tcpSocket;

        public ClientCNM()
        {

        }

        public ClientCNM(string ipAddressToSet, string portToSet)
        {
            IPAddress ipAddress;
            int port;

            if (IPAddress.TryParse(ipAddressToSet, out ipAddress) == false)
                throw (new System.Exception("Invalid IP Address"));
            if (Int32.TryParse(portToSet, out port) == false)
                throw (new System.Exception("Invalid Port"));
            this.tcpSocket = new mognetwork.TcpSocket(ipAddress, port);
            this.tcpSocket.connect();
        }

        public void startClient(DLLManager dllManager)
        {
            ListenerOfSocket lh = new ListenerOfSocket();
            lh.setDLLManager(dllManager);
            lh.setTcpSocket(this.tcpSocket);
            mognetwork.TcpThreadListener ttl = new mognetwork.TcpThreadListener((mognetwork.ListenerHandler)lh, this.tcpSocket);
            ttl.start();
            mognetwork.Packet lol = new mognetwork.Packet();


            lol.addInt32(0);
            lol.addInt32(2);   
            this.tcpSocket.sendDatas(lol);
        }

        public void networkCore(DLLManager managerOfDLL, string request)
        {
            if (request.Length == 0)
                throw (new System.Exception("Invalid request : empty request"));
            if (request[0] > '9' || request[0] < '0')
                throw (new System.Exception("Invalid request : invalid plugin number"));
            APlugin plugin = this.getPluginWithGoodNumber(managerOfDLL, request[0] - '0');
            if (plugin == null)
                throw (new System.Exception("Invalid request : invalid plugin number or plugin"));
        }

        public APlugin getPluginWithGoodNumber(DLLManager managerOfDLL, int pluginNumber)
        {
            int counter = 0;
            int pluginsCount = managerOfDLL.getPluginsOfClient().Count;

            counter = 0;
            while (counter < pluginsCount)
            {
                Console.WriteLine(pluginNumber + " " + managerOfDLL.getPluginsOfClient()[counter].getNumberOfPlugin());
                if (managerOfDLL.getPluginsOfClient()[counter].getNumberOfPlugin() == pluginNumber)
                    return (managerOfDLL.getPluginsOfClient()[counter].getPluginObject());
                ++counter;
            }
            return (null);
        }
    }
}