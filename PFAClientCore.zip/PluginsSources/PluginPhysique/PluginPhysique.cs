﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PluginPhysique : APlugin
{
    public PluginPhysique()
        : base()
    {
        Console.WriteLine("Physics plugin created");
    }

    public override void doRequest(List<byte> datas, mognetwork.TcpSocket tcpSocket)
    {
        mognetwork.Packet packetToSend = new mognetwork.Packet();

        packetToSend.addInt32(0);
        packetToSend.addString("Physique sended");
        tcpSocket.sendDatas(packetToSend);
        Console.Write("Physique : ");
        foreach (byte b in datas)
            Console.Write((char)b);
    }
}
