﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PluginItem : APlugin
{
    public PluginItem()
        : base()
    {
        Console.WriteLine("Items plugin created");
    }

    public override void doRequest(List<byte> datas, mognetwork.TcpSocket tcpSocket)
    {
        mognetwork.Packet packetToSend = new mognetwork.Packet();

        packetToSend.addInt32(0);
        packetToSend.addString("Item sended");
        tcpSocket.sendDatas(packetToSend);
        Console.Write("Item : ");
        foreach (byte b in datas)
            Console.Write((char)b);
    }
}
