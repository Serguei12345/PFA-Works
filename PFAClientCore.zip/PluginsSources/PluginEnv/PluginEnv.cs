﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PluginEnv : APlugin
{
    public PluginEnv() : base()
    {
        Console.WriteLine("Environment plugin created");
    }

    public override void doRequest(List<byte> datas, mognetwork.TcpSocket tcpSocket)
    {
        mognetwork.Packet packetToSend = new mognetwork.Packet();

        packetToSend.addInt32(0);
        packetToSend.addString("Env sended");
        tcpSocket.sendDatas(packetToSend);
        Console.Write("Environment : ");
        foreach (byte b in datas)
            Console.Write((char)b);
    }
}

