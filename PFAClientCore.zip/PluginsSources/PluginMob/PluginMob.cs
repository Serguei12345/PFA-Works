﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PluginMob : APlugin
{
    public PluginMob()
        : base()
    {
        Console.WriteLine("Mobs plugin created");
    }

    public override void doRequest(List<byte> datas, mognetwork.TcpSocket tcpSocket)
    {
        mognetwork.Packet packetToSend = new mognetwork.Packet();

        packetToSend.addInt32(0);
        packetToSend.addString("Mob sended");
        tcpSocket.sendDatas(packetToSend);
        Console.Write("Mob : ");
        foreach (byte b in datas)
            Console.Write((char)b);
    }
}
