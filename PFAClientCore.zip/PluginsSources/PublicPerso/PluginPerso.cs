﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PluginPerso : APlugin
{
    public PluginPerso()
        : base()
    {
        Console.WriteLine("Persos plugin created");
    }

    public override void doRequest(List<byte> datas, mognetwork.TcpSocket tcpSocket)
    {
        Console.WriteLine("Step 1");
        mognetwork.Packet packetToSend = new mognetwork.Packet();

        Console.WriteLine("Step 1");
        packetToSend.addInt32(0);
        Console.WriteLine("Step 2");
        packetToSend.addString("Perso sended");
        Console.WriteLine("Step 3");
        tcpSocket.sendDatas(packetToSend);
        Console.WriteLine("Step 4"); 
        Console.Write("Perso : ");
        foreach (byte b in datas)
            Console.Write((char)b);
        Console.WriteLine("Step 5");
    }
}
